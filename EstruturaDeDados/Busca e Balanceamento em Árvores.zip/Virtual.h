class VNodo{
 //Fazer com t=3
 
};

class Arvore
{
    virtual VNodo * inserir(VNodo *raizAtual, string nomeInformado, int cepInformado) {}
    virtual VNodo * remover(VNodo *raizAtual, int cepInformado) {}
    virtual VNodo * emOrdem(VNodo *raizAtual) {} // Retonar um array de VNodo
    virtual VNodo * posOrdem(VNodo *raizAtual) {} // Retonar um array de VNodo
    virtual VNodo * preOrdem(VNodo *raizAtual) {} // Retonar um array de VNodo
 };